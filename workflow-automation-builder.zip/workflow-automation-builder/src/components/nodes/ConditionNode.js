import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

const ConditionNode = ({ data }) => {
  return (
    <div className="condition-node node">
      <Handle type="target" position={Position.Top} />
      <div className="node-content">
        <div className="node-header condition">Condition</div>
        <div className="node-label">{data.label}</div>
        {data.condition && <div className="node-condition">{data.condition}</div>}
        <div className="branches">
          <div className="true-branch">True: {data.trueLabel || 'True'}</div>
          <div className="false-branch">False: {data.falseLabel || 'False'}</div>
        </div>
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        id="true"
        className="true-handle"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        id="false"
        className="false-handle"
        style={{ left: '75%' }}
      />
    </div>
  );
};

export default memo(ConditionNode);