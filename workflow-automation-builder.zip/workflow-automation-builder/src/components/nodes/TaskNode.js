import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

const TaskNode = ({ data }) => {
  return (
    <div className="task-node node">
      <Handle type="target" position={Position.Top} />
      <div className="node-content">
        <div className="node-header task">Task</div>
        <div className="node-label">{data.label}</div>
        {data.assignee && <div className="node-assignee">Assignee: {data.assignee}</div>}
        {data.dueDate && <div className="node-due-date">Due: {data.dueDate}</div>}
        <div className="node-status">Status: {data.status || 'Not Started'}</div>
      </div>
      <Handle type="source" position={Position.Bottom} />
    </div>
  );
};

export default memo(TaskNode);