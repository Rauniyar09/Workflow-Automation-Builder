import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

const NotificationNode = ({ data }) => {
  return (
    <div className="notification-node node">
      <Handle type="target" position={Position.Top} />
      <div className="node-content">
        <div className="node-header notification">Notification</div>
        <div className="node-label">{data.label}</div>
        {data.recipient && <div className="node-recipient">To: {data.recipient}</div>}
        {data.channel && <div className="node-channel">Via: {data.channel}</div>}
        {data.message && (
          <div className="node-message">
            Message: {data.message.length > 30 ? `${data.message.substring(0, 30)}...` : data.message}
          </div>
        )}
      </div>
      <Handle type="source" position={Position.Bottom} />
    </div>
  );
};

export default memo(NotificationNode);