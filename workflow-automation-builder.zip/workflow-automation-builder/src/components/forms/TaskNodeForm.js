import React from 'react';
import { useForm } from 'react-hook-form';

const TaskNodeForm = ({ node, onSubmit, onCancel }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      label: node.data.label || '',
      assignee: node.data.assignee || '',
      dueDate: node.data.dueDate || '',
      status: node.data.status || 'Not Started',
    },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-group">
        <label htmlFor="label">Task Name</label>
        <input
          id="label"
          type="text"
          {...register('label', { required: 'Task name is required' })}
        />
        {errors.label && <span className="error">{errors.label.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="assignee">Assignee</label>
        <input id="assignee" type="text" {...register('assignee')} />
      </div>

      <div className="form-group">
        <label htmlFor="dueDate">Due Date</label>
        <input
          id="dueDate"
          type="date"
          {...register('dueDate')}
        />
      </div>

      <div className="form-group">
        <label htmlFor="status">Status</label>
        <select id="status" {...register('status')}>
          <option value="Not Started">Not Started</option>
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
          <option value="Blocked">Blocked</option>
        </select>
      </div>

      <div className="form-actions">
        <button type="submit">Save</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default TaskNodeForm;