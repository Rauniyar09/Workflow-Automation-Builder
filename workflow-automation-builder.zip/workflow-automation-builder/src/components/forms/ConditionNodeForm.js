import React from 'react';
import { useForm } from 'react-hook-form';

const ConditionNodeForm = ({ node, onSubmit, onCancel }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      label: node.data.label || '',
      condition: node.data.condition || '',
      trueLabel: node.data.trueLabel || 'True',
      falseLabel: node.data.falseLabel || 'False',
    },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-group">
        <label htmlFor="label">Condition Name</label>
        <input
          id="label"
          type="text"
          {...register('label', { required: 'Condition name is required' })}
        />
        {errors.label && <span className="error">{errors.label.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="condition">Condition Expression</label>
        <input
          id="condition"
          type="text"
          {...register('condition', { required: 'Condition expression is required' })}
          placeholder="e.g., value > 100"
        />
        {errors.condition && <span className="error">{errors.condition.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="trueLabel">True Branch Label</label>
        <input id="trueLabel" type="text" {...register('trueLabel')} />
      </div>

      <div className="form-group">
        <label htmlFor="falseLabel">False Branch Label</label>
        <input id="falseLabel" type="text" {...register('falseLabel')} />
      </div>

      <div className="form-actions">
        <button type="submit">Save</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default ConditionNodeForm;