import React from "react";
import { useForm } from "react-hook-form";

const NotificationNodeForm = ({ node, onSubmit, onCancel }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      label: node.data.label || "",
      recipient: node.data.recipient || "",
      message: node.data.message || "",
      channel: node.data.channel || "email",
    },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-group">
        <label htmlFor="label">Notification Name</label>
        <input
          id="label"
          type="text"
          {...register("label", { required: "Notification name is required" })}
        />
        {errors.label && <span className="error">{errors.label.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="recipient">Recipient</label>
        <input
          id="recipient"
          type="text"
          {...register("recipient", { required: "Recipient is required" })}
          placeholder="e.g., email@example.com"
        />
        {errors.recipient && (
          <span className="error">{errors.recipient.message}</span>
        )}
      </div>

      <div className="form-group">
        <label htmlFor="channel">Channel</label>
        <select id="channel" {...register("channel")}>
          <option value="email">Email</option>
          <option value="sms">SMS</option>
          <option value="push">Push Notification</option>
          <option value="slack">Slack</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="message">Message</label>
        <textarea
          id="message"
          {...register("message", { required: "Message is required" })}
          placeholder="Enter notification message..."
          rows={4}
        />
        {errors.message && (
          <span className="error">{errors.message.message}</span>
        )}
      </div>

      <div className="form-actions">
        <button type="submit">Save</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default NotificationNodeForm;
