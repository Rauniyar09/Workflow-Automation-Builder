import React, { useState, useCallback, useEffect } from "react";
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
} from "reactflow";
import "reactflow/dist/style.css";
import { v4 as uuidv4 } from "uuid";
import { saveAs } from "file-saver";

// Node components
import TaskNode from "./components/nodes/TaskNode";
import ConditionNode from "./components/nodes/ConditionNode";
import NotificationNode from "./components/nodes/NotificationNode";

// NodeForm components
import TaskNodeForm from "./components/forms/TaskNodeForm";
import ConditionNodeForm from "./components/forms/ConditionNodeForm";
import NotificationNodeForm from "./components/forms/NotificationNodeForm";

// Table component
import WorkflowTable from "./components/WorkflowTable";

// Custom hooks

// Styles
import "./styles.css";
import useUndoRedo from "./ hooks/useUndoRedo";

// Node type definitions
const nodeTypes = {
  task: TaskNode,
  condition: ConditionNode,
  notification: NotificationNode,
};

// Initial nodes
const initialNodes = [
  {
    id: "1",
    type: "task",
    position: { x: 100, y: 100 },
    data: {
      label: "Start Task",
      assignee: "",
      dueDate: "",
      status: "Not Started",
    },
  },
];

const App = () => {
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [nodeFormOpen, setNodeFormOpen] = useState(false);
  const [nodeType, setNodeType] = useState("task");

  const { present, saveState, undo, redo, canUndo, canRedo } = useUndoRedo({
    nodes,
    edges,
  });

  useEffect(() => {
    if (present) {
      setNodes(present.nodes);
      setEdges(present.edges);
    }
  }, [present]);

  const onNodesChange = useCallback(
    (changes) => {
      const updatedNodes = applyNodeChanges(changes, nodes);
      setNodes(updatedNodes);
      saveState({ nodes: updatedNodes, edges });
    },
    [nodes, edges, saveState]
  );

  const onEdgesChange = useCallback(
    (changes) => {
      const updatedEdges = applyEdgeChanges(changes, edges);
      setEdges(updatedEdges);
      saveState({ nodes, edges: updatedEdges });
    },
    [nodes, edges, saveState]
  );

  const onConnect = useCallback(
    (connection) => {
      const updatedEdges = addEdge(connection, edges);
      setEdges(updatedEdges);
      saveState({ nodes, edges: updatedEdges });
    },
    [nodes, edges, saveState]
  );

  const onNodeClick = useCallback((event, node) => {
    setSelectedNode(node);
    setNodeFormOpen(true);
  }, []);

  const updateNodeData = useCallback(
    (nodeId, newData) => {
      const updatedNodes = nodes.map((node) => {
        if (node.id === nodeId) {
          return { ...node, data: { ...node.data, ...newData } };
        }
        return node;
      });

      setNodes(updatedNodes);
      saveState({ nodes: updatedNodes, edges });
      setNodeFormOpen(false);
      setSelectedNode(null);
    },
    [nodes, edges, saveState]
  );

  const deleteNode = useCallback(
    (nodeId) => {
      const updatedNodes = nodes.filter((n) => n.id !== nodeId);
      const updatedEdges = edges.filter(
        (e) => e.source !== nodeId && e.target !== nodeId
      );
      setNodes(updatedNodes);
      setEdges(updatedEdges);
      saveState({ nodes: updatedNodes, edges: updatedEdges });
    },
    [nodes, edges, saveState]
  );

  const addNode = (type) => {
    const newNode = {
      id: uuidv4(),
      type,
      position: { x: 200, y: 200 },
      data: {
        label: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      },
    };

    if (type === "task") {
      newNode.data.assignee = "";
      newNode.data.dueDate = "";
      newNode.data.status = "Not Started";
    } else if (type === "condition") {
      newNode.data.condition = "";
      newNode.data.trueLabel = "True";
      newNode.data.falseLabel = "False";
    } else if (type === "notification") {
      newNode.data.recipient = "";
      newNode.data.message = "";
      newNode.data.channel = "email";
    }

    setNodes((nds) => [...nds, newNode]);
    saveState({ nodes: [...nodes, newNode], edges });
  };

  const exportWorkflow = () => {
    const workflow = { nodes, edges };
    const blob = new Blob([JSON.stringify(workflow, null, 2)], {
      type: "application/json",
    });
    saveAs(blob, "workflow.json");
  };

  const importWorkflow = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workflow = JSON.parse(e.target.result);
          setNodes(workflow.nodes || []);
          setEdges(workflow.edges || []);
          saveState({
            nodes: workflow.nodes || [],
            edges: workflow.edges || [],
          });
        } catch (error) {
          console.error("Error importing workflow:", error);
          alert("Invalid workflow file");
        }
      };
      reader.readAsText(file);
    }
  };

  const getNodeForm = () => {
    if (!selectedNode) return null;

    switch (selectedNode.type) {
      case "task":
        return (
          <TaskNodeForm
            node={selectedNode}
            onSubmit={(data) => updateNodeData(selectedNode.id, data)}
            onCancel={() => setNodeFormOpen(false)}
          />
        );
      case "condition":
        return (
          <ConditionNodeForm
            node={selectedNode}
            onSubmit={(data) => updateNodeData(selectedNode.id, data)}
            onCancel={() => setNodeFormOpen(false)}
          />
        );
      case "notification":
        return (
          <NotificationNodeForm
            node={selectedNode}
            onSubmit={(data) => updateNodeData(selectedNode.id, data)}
            onCancel={() => setNodeFormOpen(false)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="app-container">
      <div className="header">
        <h1>Workflow Automation Builder</h1>
        <div className="controls">
          <select
            value={nodeType}
            onChange={(e) => setNodeType(e.target.value)}
          >
            <option value="task">Task</option>
            <option value="condition">Condition</option>
            <option value="notification">Notification</option>
          </select>
          <button onClick={() => addNode(nodeType)}>Add Node</button>
          <button onClick={exportWorkflow}>Export Workflow</button>
          <label className="import-button">
            Import Workflow
            <input
              type="file"
              accept=".json"
              onChange={importWorkflow}
              style={{ display: "none" }}
            />
          </label>
          <button onClick={undo} disabled={!canUndo}>
            Undo
          </button>
          <button onClick={redo} disabled={!canRedo}>
            Redo
          </button>
        </div>
      </div>

      <div className="main-content">
        <div className="flow-container">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView
          >
            <Background />
            <Controls />
            <MiniMap />
          </ReactFlow>
        </div>

        {nodeFormOpen && (
          <div className="side-panel">
            <div className="form-container">
              <h2>Configure Node</h2>
              {getNodeForm()}
            </div>
          </div>
        )}
      </div>

      <WorkflowTable
        nodes={nodes}
        onEditNode={onNodeClick}
        onDeleteNode={deleteNode}
      />
    </div>
  );
};

export default App;
